---------------------------------------------------------------------------------------------
	FLOAT : Cr�er la page d'accueil
---------------------------------------------------------------------------------------------

Le zip contient les �l�ments suivants : 

	index.html
	README.txt
	screenshot-home.png
	/assets/css/main.css
	/assets/img/ipad-hand.png
	/assets/img/ser01.png
	/assets/img/ser02.png
	/assets/img/ser03.png
	
---------------------------------------------------------------------------------------------	
Commande : Coder la page index.html selon les r�gles suivantes :
---------------------------------------------------------------------------------------------
 
	1 - Corriger le code du fichier index.html
	2 - Lier la feuille de style "assets/css/main.css" avec le fichier index.html
	3 - Ouvrir le fichier 	"screenshot-home.png" pour voir le site attendu.
	4 - Cr�er la structure n�cessaire pour accueillir le contenu pr�sent� dans l'images
		4.1 - Corriger le fichier main.css
		4.1 - Cr�er un grille avec les propri�t�s "float" avec :
			1 - 1 colonne 100%
			2 - 2 colonnes 50%
			3 - 3 colonnes 33%
		
	5 - Placer le contenu dans la grille, en cr�ant un header, un contenu principal et un footer.